package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.AddDetails;
import com.example.demo.expection.*;
import com.example.demo.repository.AddDetailRepository;

@CrossOrigin(origins = "http://localhost:3001")
@RestController
@RequestMapping("/api/v1/")
public class AddDetailsController {
	
	
	@Autowired
	private AddDetailRepository adddetailrepo;
	
	@GetMapping("/details")
	public List<AddDetails> getAllDetails(){
		return adddetailrepo.findAll();
	}
	
	@PostMapping("/details")
	public AddDetails createDetails(@RequestBody AddDetails details) {
		return adddetailrepo.save(details);
	}
	
	@GetMapping("/details/{id}")
	public ResponseEntity<AddDetails> getDetailsById(@PathVariable Long id) {
		AddDetails details = adddetailrepo.findById(id)
				.orElseThrow(() -> new Expection("ID not exist  :" + id));
		return ResponseEntity.ok(details);
	}
	
	@PutMapping("/details/{id}")
	public ResponseEntity<AddDetails> updateDetails(@PathVariable Long id, @RequestBody AddDetails addDetails){
		AddDetails details = adddetailrepo.findById(id)
				.orElseThrow(() -> new Expection("ID not exist:" + id));
		
		details.setJobname(addDetails.getJobname());
		details.setCompanyname(addDetails.getCompanyname());
		details.setLocation(addDetails.getLocation());
		details.setSalary(addDetails.getSalary());
		details.setEmailId(addDetails.getEmailId());
		
		AddDetails updatedDetails = adddetailrepo.save(details);
		return ResponseEntity.ok(updatedDetails);
	}

	
	@DeleteMapping("/details/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteEmployee(@PathVariable Long id){
		AddDetails details = adddetailrepo.findById(id)
				.orElseThrow(() -> new Expection("ID not exist :" + id));
		
		adddetailrepo.delete(details);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	
}

