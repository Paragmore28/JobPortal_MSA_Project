package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.DTO.LoginDTO;
import com.example.demo.DTO.RegDTO;
import com.example.demo.response.LoginResponse;
import com.example.demo.service.LoginService;

@RestController
//@CrossOrigin
@RequestMapping("api/v1")
public class LoginController {
	
	@Autowired
    private LoginService loginService;
	
	@GetMapping("/admin/adminProfile")
	    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
	    public String adminProfile() {
	        return "Welcome to Admin Profile";
	    }
	
	
    @PostMapping(path = "/save")
    public String saveEmployee(@RequestBody RegDTO regDTO)
    {
        String id = loginService.addUser(regDTO);
        return id;
    }
    
    @PostMapping(path = "/login")
    public ResponseEntity<?> loginEmployee(@RequestBody LoginDTO loginDTO)
    {
        LoginResponse loginResponse = loginService.loginEmployee(loginDTO);
        return ResponseEntity.ok(loginResponse);
    } 

}
